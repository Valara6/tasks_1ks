<b>Автор таска</b>: Аверин Илья Олегович <br>
<b>Название таска</b>: use_rubeus_task1 <br>
<b>Темы</b>: Rubeus for AS-REP roasting <br>
<b>Инструменты для решения задач</b>: nmap, sshprank, Rubeus, hashcat <br>
<b>Топология:</b> <br>
![tolopogy](./img/tolopogy7.png) <br>
[<b>Условие пользователю</b>](./description.md) <br>
[<b>Ожидаемое решение</b>](./solution.md) <br>
[<b>Инструкция по развёртыванию </b>](./deploy.md) <br>