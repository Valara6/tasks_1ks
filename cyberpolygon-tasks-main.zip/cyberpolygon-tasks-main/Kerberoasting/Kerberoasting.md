<b>Автор таска</b>: Непомнящих Игорь Алексеевич <br>
<b>Темы</b>: Атака Kerberoasting, с помощью SPN-записей <br>
<b>Инструменты для решения задач</b>: Mimikatz, kerberoast <br>

Атака проводится на агенте включенном в доменную группу AD, с отключенной АВ защитой, и выключенным МЭ.


![1](Screenshots/1.png)
![2](Screenshots/2.png)
![3](Screenshots/3.png)

Поиск SPN-записей

![4](Screenshots/4.png)

Извлечение MSSQL-сервера

![5](Screenshots/5.png)
![6](Screenshots/6.png)

Проверка билетов в системе

![7](Screenshots/7.png)

Запуск мимикатц

![8](Screenshots/8.png)

Выгрузим билеты Kerberos в файл (Mimikatz), восстановление хеша из билета K по словарю

![9](Screenshots/9.png)

Создадим файл для подбора паролей на кали

![10](Screenshots/10.png)

Установим kerberoast

![11](Screenshots/11.png)

Перенесем папку

![12](Screenshots/12.png)

![13](Screenshots/13.png)
