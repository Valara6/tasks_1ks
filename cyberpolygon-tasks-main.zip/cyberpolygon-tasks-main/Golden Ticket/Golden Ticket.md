<b>Автор таска</b>: Непомнящих Игорь Алексеевич <br>
<b>Темы</b>: Атака Golden Ticket <br>
<b>Инструменты для решения задач</b>: impacket, kiwi, mimikatz <br>

Установка и настройка WINDOWS SERVER

![1](Screenshots/1.png)
![2](Screenshots/2.png)
![3](Screenshots/3.png)
![4](Screenshots/4.png)
![5](Screenshots/5.png)
![6](Screenshots/6.png)
![7](Screenshots/7.png)
![8](Screenshots/8.png)
![9](Screenshots/9.png)
![10](Screenshots/10.png)
![11](Screenshots/11.png)
![12](Screenshots/12.png)
![13](Screenshots/13.png)
![14](Screenshots/14.png)
![15](Screenshots/15.png)
![16](Screenshots/16.png)
![17](Screenshots/17.png)
![18](Screenshots/18.png)
![19](Screenshots/19.png)
![20](Screenshots/20.png)
![21](Screenshots/21.png)
![22](Screenshots/22.png)
![23](Screenshots/23.png)
![24](Screenshots/24.png)
![25](Screenshots/25.png)
![26](Screenshots/26.png)
![27](Screenshots/27.png)
![28](Screenshots/28.png)
![29](Screenshots/29.png)
![30](Screenshots/30.png)
![31](Screenshots/31.png)
![32](Screenshots/32.png)

Настройка компьютера пользователя для подключения к домену

![33](Screenshots/33.png)
![34](Screenshots/34.png)
![35](Screenshots/35.png)

Выполнение атаки Golden ticket.
Установим модуль impacket на kali

![36](Screenshots/36.png)

Получение SID юзера

![37](Screenshots/37.png)

Получение дампа хешей

![38](Screenshots/38.png)

Получение удаленного доступа к системе

![39](Screenshots/39.png)

Подключимся к Серверу через мсф

![40](Screenshots/40.png)
![41](Screenshots/41.png)
![42](Screenshots/42.png)

Установим kiwi и Получим сид

![43](Screenshots/43.png)

Создадим голден тикет:

![44](Screenshots/44.png)

Создадим тикет

![45](Screenshots/45.png)

Проверим тикет

![46](Screenshots/46.png)
