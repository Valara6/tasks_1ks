<b>Информация для виртуальщиков</b>:
1. Создать домен на Win Server и ввести туда Win10
2. Win10, WinServer и Kali Linux должны находиться в одной сети
3. Создайте доменные учётки с легкими для брудфорса паролями.
4. Выключить defender и firewall на WinServ и Win10
5. Скачать Mimikatz на Win10 и Kerberoast на Kali
