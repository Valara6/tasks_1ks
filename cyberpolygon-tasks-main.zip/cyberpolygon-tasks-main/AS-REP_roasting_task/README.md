<b>Автор таска</b>: Аверин Илья Олегович <br>
<b>Темы</b> AS-REP roasting <br>
<b>Инструменты для решения задач</b>: nmap, kerbrute_linux_amd64, impacket-GetNPUsers, hashcat <br>
<b>Топология:</b> <br>
![tolopogy](./img/tolopogy6.png) <br>
[<b>Условие пользователю</b>](./description.md) <br>
[<b>Ожидаемое решение</b>](./solution.md) <br>
[<b>Инструкция по развёртыванию </b>](./deploy.md) <br>