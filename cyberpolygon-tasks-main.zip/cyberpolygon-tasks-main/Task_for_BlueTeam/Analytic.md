<b>Автор таска</b>: Непомнящих Игорь Алексеевич <br>
<b>Темы</b>: Анализ вредоносного ПО из зараженного письма и поддельного всплывающего окна. <br>
<b>Инструменты для решения задач</b>: Wireshark, сервисы VirusTotal и Hybrid-analysis <br>


![1](Screenshots/1.png)

Отобразим информацию по каждому IP:

![2](Screenshots/2.png)

iP-адрес: 10.3.14.131
MAC-адрес: 00:25:64:18:4c:2a
Производитель: Dell
Версия ОС: Windows 10 (Windows NT 10.0)
Браузер: Mozilla/5.0 AppleWebKit/537.36 Chrome/56.0.2924.87 Safari/537.36

![3](Screenshots/3.png)

iP-адрес: 10.3.14.134
MAC-адрес: 14:da:e9:5b:42:1c
Производитель: ASUSTekC
Версия ОС: Windows 7 (Windows NT 6.1) 
Браузер: Mozilla/4.0

![4](Screenshots/4.png)

iP-адрес: 10.3.14.135 
MAC-адрес: 00:26:bb:4c:6b:e1 
Производитель: Apple
Версия ОС: Apple
Браузер: SpotlightNetHelper/917.36 CFNetwork/720.5.7 Darwin/14.5.0 (x86_64)

![5](Screenshots/5.png)

Suricata обнаружила: 10.3.14.131; 10.3.14.134; 67.210.245.241; 104.155.4.180.
Также в snort выведем ip с количеством срабатываний:

![6](Screenshots/6.png)

Snort обнаружил: 10.3.14.131; 10.3.14.134; 10.3.14.135; 67.210.245.241; 104.155.4.180
На четвертой строчке видим, что зафиксирован факт передачи PE файла:

![7](Screenshots/7.png)

![8](Screenshots/8.png)

Найдена сигнатура MZ, что символизирует о том, что в трафике передавался файл PE (*.exe) 
URI: http://unittogreas.top/search.php 
Видим, что зафиксирован факт передачи shell кода:

![9](Screenshots/9.png)

Видим, что действительно передавались закодированные данные:

![10](Screenshots/10.png)

URI: http://unittogreas.top/search.php

![11](Screenshots/11.png)