1. Настроить kali, Win10 Pro и Win16 Server в одной подсети (Например, подсеть: 192.168.1.0/24)
2. Поднять домен (например, имя Polytech) на Win16 Server и ввести туда Win10 Pro.
3. Скачать sshprank, impacket, hashcat, nmap на kali.
4. Cоздать пользователя в домене с логином Petr и легким паролем. (Например, Qwerty12)
5. Открыть ssh-порт с аутентификацией по паролю и неограниченными попытками аутентификации.
6. Сделать бэкап NTDS в C:\temp: <br>
   Ntdsutil <br>
   activate instance ntds <br>
   ifm <br>
   create full C:\temp
